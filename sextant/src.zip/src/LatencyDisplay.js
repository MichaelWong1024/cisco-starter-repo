import React, { useEffect, useState } from 'react';

function LatencyDisplay() {
  const [latency, setLatency] = useState(null);

  useEffect(() => {
    const ws = new WebSocket('ws://localhost:55455');

    ws.onmessage = (event) => {
      const packet = JSON.parse(event.data);
      const currentTime = new Date().getTime();
      const packetTime = packet.data;
      const latency = currentTime - packetTime;
      setLatency(latency);
    };

    return () => ws.close(); // Clean up the WebSocket connection when the component unmounts
  }, []);

  return (
    <div>
      <h3>Packet Latency:</h3>
      <p>{latency ? `${latency} ms` : 'Calculating...'}</p>
    </div>
  );
}

export default LatencyDisplay;

